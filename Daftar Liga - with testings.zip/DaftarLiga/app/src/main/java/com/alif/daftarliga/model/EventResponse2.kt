package com.alif.daftarliga.model

data class EventResponse2(val event: ArrayList<Event2>)